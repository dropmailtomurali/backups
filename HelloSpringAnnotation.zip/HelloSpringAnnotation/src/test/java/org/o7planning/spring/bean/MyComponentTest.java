package org.o7planning.spring.bean;

import org.junit.Test;

import static org.junit.Assert.*;

public class MyComponentTest {

    @Test
    public void showAppInfo() {

    }
}