package org.o7planning.spring.lang;

// A Language
public interface Language {

    // Get a greeting
    public String getGreeting();

    // Get a bye
    public String getBye();

}